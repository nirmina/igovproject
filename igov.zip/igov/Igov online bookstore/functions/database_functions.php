<?php
function db_connect() {
    $conne = mysqli_connect("localhost", "root", "root", "bookshop", 3307);
    if (!$conne) {
        echo "Can't connect to database: " . mysqli_connect_error($conne);
        exit;
    }
    return $conne;
}

function select4LatestBook($conn) {
    $row = array();
    $query = "SELECT book_isbn, book_image FROM books ORDER BY book_isbn DESC";
    $result = mysqli_query($conn, $query);
    if (!$result) {
        echo "Can't retrieve data: " . mysqli_error($conn);
        exit;
    }
    for ($i = 0; $i < 4; $i++) {
        array_push($row, mysqli_fetch_assoc($result));
    }
    return $row;
}

function getBookByIsbn($conn, $isbn) {
    $query = "SELECT * FROM books WHERE book_isbn = '$isbn'";
    $result = mysqli_query($conn, $query);
    if (!$result) {
        echo "Query failed: " . mysqli_error($conn);
        return null;
    }
    return $result;
}

function getCartId($conn, $customerid) {
    $query = "SELECT id FROM cart WHERE customerid = '$customerid'";
    $result = mysqli_query($conn, $query);
    if (!$result) {
        echo "Retrieve data failed: " . mysqli_error($conn);
        exit;
    }
    $row = mysqli_fetch_assoc($result);
    return $row['id'];
}

function insertIntoCart($conn, $customerid, $date) {
    $query = "INSERT INTO cart(customerid, date) VALUES('$customerid', '$date')";
    $result = mysqli_query($conn, $query);
    if (!$result) {
        echo "Insert Cart failed: " . mysqli_error($conn);
        exit;
    }
}

function getBookPrice($isbn) {
    $conn = db_connect();
    $query = "SELECT book_price FROM books WHERE book_isbn = '$isbn'";
    $result = mysqli_query($conn, $query);
    if (!$result) {
        echo "Get book price failed: " . mysqli_error($conn);
        exit;
    }
    $row = mysqli_fetch_assoc($result);
    return $row['book_price'];
}

function getCustomerId($name, $address, $city,  $country) {
    $conn = db_connect();
    $query = "SELECT customerid FROM customers WHERE 
              name = '$name' AND 
              address = '$address' AND 
              city = '$city' AND 
              country = '$country'";
    $result = mysqli_query($conn, $query);
    if ($result) {
        $row = mysqli_fetch_assoc($result);
        return $row['customerid'];
    } else {
        return null;
    }
}

function getCustomerIdbyEmail($email) {
    $conn = db_connect();
    $query = "SELECT * FROM customers WHERE email = '$email'";
    $result = mysqli_query($conn, $query);
    if ($result) {
        return mysqli_fetch_assoc($result);
    } else {
        return null;
    }
}

function getPubName($conn, $pubid) {
    $query = "SELECT publisher_name FROM publisher WHERE publisherid = '$pubid'";
    $result = mysqli_query($conn, $query);
    if (!$result) {
        echo "Can't retrieve data: " . mysqli_error($conn);
        exit;
    }
    if (mysqli_num_rows($result) == 0) {
        echo "Not Set";
    }

    $row = mysqli_fetch_assoc($result);
    return $row['publisher_name'];
}

function getCatName($conn, $catid) {
    $query = "SELECT category_name FROM category WHERE categoryid = '$catid'";
    $result = mysqli_query($conn, $query);
    if (!$result) {
        echo "Can't retrieve data: " . mysqli_error($conn);
        exit;
    }
    if (mysqli_num_rows($result) == 0) {
        echo "Not Set";
    }

    $row = mysqli_fetch_assoc($result);
    return $row['category_name'];
}

function getAll($conn) {
    $query = "SELECT * FROM books ORDER BY book_isbn DESC";
    $result = mysqli_query($conn, $query);
    if (!$result) {
        echo "Can't retrieve data: " . mysqli_error($conn);
        exit;
    }
    return $result;
}

function getAllPublishers($conn) {
    $query = "SELECT * FROM publisher ORDER BY publisher_name ASC";
    $result = mysqli_query($conn, $query);
    if (!$result) {
        echo "Can't retrieve data: " . mysqli_error($conn);
        exit;
    }
    return $result;
}

function getAllCategories($conn) {
    $query = "SELECT * FROM category ORDER BY category_name ASC";
    $result = mysqli_query($conn, $query);
    if (!$result) {
        echo "Can't retrieve data: " . mysqli_error($conn);
        exit;
    }
    return $result;
}

function total_price($cart){
	$price = 0.0;
	if(is_array($cart)){
		  foreach($cart as $isbn => $qty){
			  $bookprice = getbookprice($isbn);
			  if($bookprice){
				  $price += $bookprice * $qty;
			  }
		  }
	}
	return $price;
}

function total_items($cart){
	$items = 0;
	if(is_array($cart)){
		foreach($cart as $isbn => $qty){
			$items += $qty;
		}
	}
	return $items;
}
?>
