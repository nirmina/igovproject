<?php
    if(!isset($_SESSION)) 
    { 
        session_start(); 
    } 
    require_once "./functions/database_functions.php";
    if(isset($_SESSION['email'])){
        $customer = getCustomerIdbyEmail($_SESSION['email']);
        $name = $customer['firstname'];
    }
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title><?php echo $title; ?></title>

    <link href="./bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="./bootstrap/css/jumbotron.css" rel="stylesheet">

    <style>
      /* Navbar Styles */
      .navbar-inverse {
          background-color: rgb(3, 69, 120) !important;
      }
      .navbar-header {
          display: flex;
          align-items: center;
      }
      .navbar-header img {
          width: 75px;
          height: 50px;
          margin-right: 15px;
      }
      .navbar-header a {
          text-decoration: none;
      }
      .search-bar {
          flex-grow: 1;
          max-width: 600px;
          margin-left: 20px;
      }
      .search-bar input {
          width: 100%;
      }
      .navbar-collapse ul {
          display: flex;
          align-items: center;
          list-style: none;
          gap: 15px;
      }
      .navbar-collapse ul li a {
          color: white;
          text-decoration: none;
          font-size: 16px;
      }
      .navbar-collapse ul li a:hover {
          text-decoration: underline;
      }

      /* Styles for Lists */
      .publisher-list {
          padding-left: 40px;
          margin-top: 20px;
      }
      .publisher-list li {
          list-style-type: disc;
          margin-bottom: 10px;
      }
      .publisher-list a {
          text-decoration: none;
          color: #007bff;
      }
      .publisher-list a:hover {
          text-decoration: underline;
      }
    </style>
  </head>

  <body>
    <nav class="navbar navbar-inverse navbar-fixed-top">
      <div class="container">
        <!-- Logo and Search -->
        <div class="navbar-header">
          <a href="index.php">
            <img src="bootstrap/img/logo.png" alt="iGov Logo">
          </a>
          <form method="post" action="search_book.php" class="search-bar">
            <input type="text" class="form-control" placeholder="Search By Keyword" name="text">
          </form>
        </div>

        <!-- Navigation Links -->
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav navbar-right">
              <li><a href="publisher_list.php"><span class="glyphicon glyphicon-paperclip"></span>&nbsp; Publishers</a></li>
              <li><a href="category_list.php"><span class="glyphicon glyphicon-list-alt"></span>&nbsp; Categories</a></li>
              <li><a href="books.php"><span class="glyphicon glyphicon-book"></span>&nbsp; Books</a></li>
              <li><a href="cart.php"><span class="glyphicon glyphicon-shopping-cart"></span>&nbsp; My Cart</a></li>
              <?php 
               if(isset($_SESSION['user'])){
                 echo '<li><a href="logout.php"><span class="glyphicon glyphicon-log-out"></span>&nbsp; LogOut</a></li>';
                 echo '<li><a href="profile.php"><span class="glyphicon glyphicon-user"></span>&nbsp;' . $name . '</a></li>';
               } else {
                 echo '<li><a href="signin.php"><span class="glyphicon glyphicon-log-in"></span>&nbsp; Signin</a></li>';
                 echo '<li><a href="signup.php"><span class="glyphicon glyphicon-plus-sign"></span>&nbsp;Sign up</a></li>';
               }
              ?>
          </ul>
        </div>
      </div>
    </nav>

    <?php if(isset($title) && $title == "Index") { ?>
    <!-- Main jumbotron -->
    <div class="jumbotron" >
      <div class="container">
        <h1 style="text-align: center; margin: 5% auto; color: rgb(3, 69, 120);">Welcome To Igov Online Bookstore</h1>   
        <p style="text-align: center; margin: 5% auto; color: black;">Here you can find all books related to Science and Informatics</p>     
      </div>
    </div>
    <?php } ?>

    <!-- Main Content -->
    <div class="container" id="main" ></div>
  </body>
</html>
